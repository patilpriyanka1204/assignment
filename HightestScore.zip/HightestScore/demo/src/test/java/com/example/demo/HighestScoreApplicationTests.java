package com.example.demo;

import org.junit.jupiter.api.Test;
import static org.junit.Assert.assertEquals;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HighestScoreApplicationTests {

	@Test
	void findMaxScoreTest() {
		System.out.println("test case cube");
		assertEquals("Love",HighScoringWord.maxWordScore("we love coffee"));
	}


}
